package com.its.board;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Board20220624ApplicationTests {

    @Test
    void contextLoads() {
    }

}
