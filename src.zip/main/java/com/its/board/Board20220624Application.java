package com.its.board;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Board20220624Application {

    public static void main(String[] args) {
        SpringApplication.run(Board20220624Application.class, args);
    }

}
